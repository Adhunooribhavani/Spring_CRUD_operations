package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Certificate;
import com.example.demo.service.CertificateService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
public class CertificateController {
@Autowired
CertificateService cs1;
@PostMapping(" /certificates")
public  Certificate saveCertificate(@RequestBody  Certificate certificate) {
    //TODO: process POST request
    
    return cs1.saveCertificate(certificate);
}

}
