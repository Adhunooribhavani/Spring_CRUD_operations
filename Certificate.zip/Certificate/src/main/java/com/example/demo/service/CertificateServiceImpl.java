package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Certificate;
import com.example.demo.repository.CertificateRepository;

@Service
public class CertificateServiceImpl implements CertificateService {
@Autowired
 CertificateRepository cr1;

@Override
public Certificate saveCertificate(Certificate certificate) {
	// TODO Auto-generated method stub
	return cr1.save( certificate);
}
 
}
